# import json
# from types import SimpleNamespace

# def _json_object_hook(d):
#     return SimpleNamespace(**{k: _json_object_hook(v) if isinstance(v, dict) else v for k, v in d.items()})

# def json2obj(data):
#     return json.loads(data, object_hook=_json_object_hook)

# def extract(file_path):
#     with open(file_path, 'r') as file:
#         data = json.load(file)
#     return data

# def prettify_json(data, output_file_path):
#     with open(output_file_path, 'w') as file:
#         json.dump(data, file, indent=4)

# file_path = 'pennsylvania_plans_2021.json'
# output_file_path = '2021_pretty.json'
# data = extract(file_path)
# prettify_json(data, output_file_path)

fileP = "find_query.json"
import json
import os
from collections import defaultdict


def analyze_structure(
    data,
    parent=None,
    tables=defaultdict(set),
    parent_tables=defaultdict(set),
    table_parents={},
):
    if isinstance(data, dict):
        table_name = parent if parent else "root"
        parent_tables[table_name].add(parent)  # Track the parent table
        for key, value in data.items():
            if isinstance(value, dict):
                table_parents[key] = table_name  # Record the parent of this table
                analyze_structure(
                    value,
                    parent=key,
                    tables=tables,
                    parent_tables=parent_tables,
                    table_parents=table_parents,
                )
            elif isinstance(value, list) and value and isinstance(value[0], dict):
                table_parents[key] = table_name  # Record the parent of this table
                analyze_structure(
                    value[0],
                    parent=key,
                    tables=tables,
                    parent_tables=parent_tables,
                    table_parents=table_parents,
                )
            else:
                tables[table_name].add(key)
    elif isinstance(data, list):
        for item in data:
            analyze_structure(
                item,
                parent=parent,
                tables=tables,
                parent_tables=parent_tables,
                table_parents=table_parents,
            )
    return tables, parent_tables, table_parents


def generate_tables(tables, parent_tables, table_parents):
    for table, attributes in tables.items():
        parent_table = table_parents.get(table, "None")  # Get the parent table, if any
        # if table in parent_tables:
        #     attributes -= set(tables.keys())  # Remove nested tables from attributes
        print(f"Table: {table} (Parent: {parent_table})")
        print("Attributes:", ", ".join(attributes))
        print()


# Get all JSON files in the current directory
json_files = [f for f in os.listdir(".") if f.endswith(".json")]

for fileP in json_files:
    with open(fileP, "r") as file:
        print(f"\nGenerating tables for file: {fileP}\n")
        json_data = json.load(file)

    tables, parent_tables, table_parents = analyze_structure(json_data)
    generate_tables(tables, parent_tables, table_parents)

    # Pause and wait for user input before moving to the next file
    input("Press Enter to continue to the next file...")
